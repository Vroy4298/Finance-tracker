import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import SummaryCards from "../components/SummaryCards";
import TransactionList from "../components/TransactionList";
import FinanceChart from "../components/FinanceChart";
import AddTransactionModal from "../components/AddTransactionModal";
import Filters from "../components/Filters";
import { TransactionProvider } from "../context/TransactionContext";

function Dashboard() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.body.className = darkMode ? "dark" : "light";
  }, [darkMode]);

  return (
    <TransactionProvider>
      <div className="page-wrapper">
        <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />

        <div className="container">
          <div className="top-section">
            <SummaryCards />
            <div className="chart-wrapper">
              <FinanceChart />
            </div>
          </div>

          <Filters />
          <TransactionList />
        </div>

        <AddTransactionModal />
      </div>
    </TransactionProvider>
  );
}

export default Dashboard;
