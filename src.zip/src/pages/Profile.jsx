function Profile() {
  return (
    <div style={{ padding: "40px" }}>
      <h2>Profile Page</h2>
    </div>
  );
}

export default Profile;
