import { useContext } from "react";
import { TransactionContext } from "../context/TransactionContext";

function Filters() {
  const {
    searchTerm,
    setSearchTerm,
    filterType,
    setFilterType,
    sortOption,
    setSortOption,
  } = useContext(TransactionContext);

  return (
    <div style={{ padding: "20px" }}>
      <input
        type="text"
        placeholder="Search by title..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <select
        value={filterType}
        onChange={(e) => setFilterType(e.target.value)}
        style={{ marginLeft: "10px" }}
      >
        <option value="all">All</option>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>

      <select
        value={sortOption}
        onChange={(e) => setSortOption(e.target.value)}
        style={{ marginLeft: "10px" }}
      >
        <option value="newest">Newest</option>
        <option value="amount-high">Amount High → Low</option>
        <option value="amount-low">Amount Low → High</option>
      </select>
    </div>
  );
}

export default Filters;
