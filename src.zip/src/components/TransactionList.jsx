import { useContext } from "react";
import { TransactionContext } from "../context/TransactionContext";

function TransactionList() {
  const { transactions, deleteTransaction, loading } =
     useContext(TransactionContext);


  return (
    <div className="transaction-list">
      <h3>Transactions</h3>

{loading && (
  <p style={{ padding: "20px" }}>Loading transactions...</p>
)}

{transactions.length === 0 && !loading && (
  <div className="empty-state">
    <p>No transactions yet</p>
  </div>
)}

{transactions.map((t) => (
        <div
          key={t.id}
          className={`transaction-card ${t.type}`}
        >
          <div className="transaction-info">
            <h4>{t.title}</h4>
            <p>{t.type}</p>
          </div>

          <div className="transaction-actions">
            <span className="amount">
              ₹{t.amount}
            </span>

            <button
              className="delete-btn"
              onClick={() => deleteTransaction(t.id)}
            >
              ✕
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TransactionList;
