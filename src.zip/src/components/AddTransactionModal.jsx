import { useState, useContext, useEffect } from "react";
import { TransactionContext } from "../context/TransactionContext";

function AddTransactionModal() {
  const {
    addTransaction,
    updateTransaction,
    transactions,
  } = useContext(TransactionContext);

  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState("income");

  const openModal = () => {
    setIsOpen(true);
  };

  const closeModal = () => {
    setIsOpen(false);
    setEditingId(null);
    setTitle("");
    setAmount("");
    setType("income");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editingId) {
      await updateTransaction(editingId, {
        title,
        amount: Number(amount),
        type,
      });
    } else {
      await addTransaction({
        title,
        amount: Number(amount),
        type,
      });
    }

    closeModal();
  };

  return (
    <>
      {/* Floating Add Button */}
      <button className="floating-btn" onClick={openModal}>
        +
      </button>

      {/* Modal */}
      {isOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Add Transaction</h3>

            <form onSubmit={handleSubmit}>
              <input
                type="text"
                placeholder="Title"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />

              <input
                type="number"
                placeholder="Amount"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />

              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>

              <div className="modal-actions">
                <button type="submit">Save</button>
                <button type="button" onClick={closeModal}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

export default AddTransactionModal;
