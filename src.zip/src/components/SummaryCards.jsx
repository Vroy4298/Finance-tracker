import { useContext } from "react";
import { TransactionContext } from "../context/TransactionContext";

function SummaryCards() {
  const { transactions } = useContext(TransactionContext);

  const income = transactions
    .filter((t) => t.type === "income")
    .reduce((acc, t) => acc + t.amount, 0);

  const expense = transactions
    .filter((t) => t.type === "expense")
    .reduce((acc, t) => acc + t.amount, 0);

  const balance = income - expense;

  return (
    <div className="summary-cards">
      <div className="card balance">Balance: ₹{balance}</div>
      <div className="card income">Income: ₹{income}</div>
      <div className="card expense">Expense: ₹{expense}</div>
    </div>
  );
}

export default SummaryCards;
